# DC Tracking Tool Starter

A simple starter for a DC tracking tool with React frontend and Node.js backend.